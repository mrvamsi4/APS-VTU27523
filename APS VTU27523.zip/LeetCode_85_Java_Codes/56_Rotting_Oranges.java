import java.util.*;
class Solution {
    public int orangesRotting(int[][] grid){
        int m=grid.length,n=grid[0].length,fresh=0,minutes=0;Queue<int[]>q=new LinkedList<>();
        for(int i=0;i<m;i++)for(int j=0;j<n;j++){if(grid[i][j]==2)q.offer(new int[]{i,j});else if(grid[i][j]==1)fresh++;}
        int[][] dirs={{1,0},{-1,0},{0,1},{0,-1}};
        while(!q.isEmpty()&&fresh>0){int size=q.size();minutes++;while(size-->0){int[]p=q.poll();for(int[]d:dirs){int r=p[0]+d[0],c=p[1]+d[1];if(r>=0&&r<m&&c>=0&&c<n&&grid[r][c]==1){grid[r][c]=2;fresh--;q.offer(new int[]{r,c});}}}}
        return fresh==0?minutes:-1;
    }
}
