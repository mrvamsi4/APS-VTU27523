class Solution {
    public int maxAreaOfIsland(int[][] grid){
        int best=0;for(int i=0;i<grid.length;i++)for(int j=0;j<grid[0].length;j++)if(grid[i][j]==1)best=Math.max(best,dfs(grid,i,j));return best;
    }
    private int dfs(int[][]g,int r,int c){if(r<0||r>=g.length||c<0||c>=g[0].length||g[r][c]!=1)return 0;g[r][c]=0;return 1+dfs(g,r+1,c)+dfs(g,r-1,c)+dfs(g,r,c+1)+dfs(g,r,c-1);}
}
